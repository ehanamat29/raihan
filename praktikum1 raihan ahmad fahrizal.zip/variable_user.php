<?php
// Definisikan variable
$nama = 'Rosalie Naurah';
$umur = 13;
$berat = 22.4;

echo 'Nama : ' .$nama;
echo '<br/>Umur : ' .$umur. 'Tahun';
echo '<br/>Berat : ' .$berat. ' Kg ';

echo "<br/> Hello $nama Apakabar";
echo "<br/> Hai nama saya $nama Umur saya $umur Berat badan saya $berat Kg, Salam kenal semua nya";
echo "<hr>";
?>